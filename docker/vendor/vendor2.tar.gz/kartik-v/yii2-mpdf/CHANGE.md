Change Log: `yii2-mpdf`
=======================

## Version 1.0.1

**Date:** 08-Apr-2016

- (enh #12): New `tempPath` property to allow setting temporary folder for mpdf font data.
- (enh #13): Default mode setting for Asian Languages via `Pdf::MODE_ASIAN`.
- (enh #14): Initialize with default mPDF configuration options.
- Update mpdf source to use repo https://github.com/mpdf/mpdf.
- Add branch alias for dev-master latest release.

## Version 1.0.0

**Date:** 03-Nov-2014

- Initial release.
- Set release to stable.
