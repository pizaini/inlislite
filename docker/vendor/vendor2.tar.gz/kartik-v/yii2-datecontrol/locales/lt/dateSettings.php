<?php
/**
 * Locale translations for date control and php-date-formatter settings.
 * NOTE: this file must be saved in UTF-8 encoding.
 */
return [
	'days' => ["Sekmadienis", "Pirmadienis", "Antradienis", "Trečiadienis", "Ketvirtadienis", "Penktadienis", "Šeštadienis", "Sekmadienis"],
	'daysShort' => ["S", "Pr", "A", "T", "K", "Pn", "Š", "S"],
	'months' => ["Sausis", "Vasaris", "Kovas", "Balandis", "Gegužė", "Birželis", "Liepa", "Rugpjūtis", "Rugsėjis", "Spalis", "Lapkritis", "Gruodis"],
	'monthsShort' => ["Sau", "Vas", "Kov", "Bal", "Geg", "Bir", "Lie", "Rugp", "Rugs", "Spa", "Lap", "Gru"],
    'meridiem' => ['AM', 'PM']
];
?>
