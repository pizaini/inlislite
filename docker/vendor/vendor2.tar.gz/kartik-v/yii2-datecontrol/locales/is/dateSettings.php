<?php
/**
 * Locale translations for date control and php-date-formatter settings.
 * NOTE: this file must be saved in UTF-8 encoding.
 */
return [
	'days' => ["Sunnudagur", "Mánudagur", "Þriðjudagur", "Miðvikudagur", "Fimmtudagur", "Föstudagur", "Laugardagur", "Sunnudagur"],
	'daysShort' => ["Sun", "Mán", "Þri", "Mið", "Fim", "Fös", "Lau", "Sun"],
	'months' => ["Janúar", "Febrúar", "Mars", "Apríl", "Maí", "Júní", "Júlí", "Ágúst", "September", "Október", "Nóvember", "Desember"],
	'monthsShort' => ["Jan", "Feb", "Mar", "Apr", "Maí", "Jún", "Júl", "Ágú", "Sep", "Okt", "Nóv", "Des"],
    'meridiem' => ['AM', 'PM']
];
?>
