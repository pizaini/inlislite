version 1.1.0
=============

**Date:** 19-Nov-2014

- bug #1: Fix dependency on \kartik\growl\Growl

version 1.0.0
=============

**Date:** 08-Nov-2014

- Initial release 
- Sub repo split from [yii2-widgets](https://github.com/kartik-v/yii2-widgets)