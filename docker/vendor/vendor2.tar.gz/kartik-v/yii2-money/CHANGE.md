version 1.2.1
=============
**Date:** 17-Jun-2015

- (enh #13): Set composer version dependencies.

version 1.2.0
=============
**Date:** 25-Nov-2014

- (enh #7): Enhance widget to use updated plugin registration from Krajee base

version 1.1.0
=============
**Date:** 20-Nov-2014

- Set dependency on Krajee base components
- (bug #6): Extend from the correct base widget `kartik\base\InputWidget`.
- Set release to stable

version 1.0.0
=============
**Date**: 01-Jun-2014

- Initial release
- PSR4 alias change