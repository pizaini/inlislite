module.exports = require('./js/load-image')

require('./js/load-image-exif')
require('./js/load-image-exif-map')
require('./js/load-image-meta')
require('./js/load-image-orientation')
