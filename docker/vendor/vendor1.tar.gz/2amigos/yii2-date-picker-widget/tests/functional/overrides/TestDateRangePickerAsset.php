<?php
/**
 *
 * TestDateRangePickerAssset.php
 *
 * Date: 20/03/15
 * Time: 13:38
 * @author Antonio Ramirez <amigo.cobos@gmail.com>
 * @link http://www.ramirezcobos.com/
 * @link http://www.2amigos.us/
 */

namespace tests\overrides;


use dosamigos\datepicker\DateRangePickerAsset;

class TestDateRangePickerAsset extends DateRangePickerAsset
{
    public $sourcePath = '@tests/../../src/assets';
}
