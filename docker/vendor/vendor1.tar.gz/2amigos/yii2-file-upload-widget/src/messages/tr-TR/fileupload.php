/**
* @author Erkan Karataş https://github.com/karataserkan
*/
return [
    'Add files' => 'Dosyaları Ekle',
    'Start upload' => 'Yüklemeye Başla',
    'Cancel upload' => 'Yüklemeyi İptal Et',
    'Start' => 'Başla',
    'Cancel' => 'İptal',
    'Error' => 'Hata',
    'Delete' => 'Sil',
    'Processing' => 'İşleniyor',
];
